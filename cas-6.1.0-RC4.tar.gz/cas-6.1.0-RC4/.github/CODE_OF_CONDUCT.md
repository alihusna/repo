# Code of conduct

CAS is a sponsored Apereo project participating in the [Apereo Welcoming Policy][].

[Apereo Welcoming Policy]: https://www.apereo.org/content/apereo-welcoming-policy
